ALL_LOCATORS = {

    # -----------------------------------------------------------------------------------------------------------
    # Entry is like key and value; Here Key is Page Object Class,
    # and Value is again having key, value pair as ATTRIBUTE_NAME : VALUE_WITH_LOCATOR_TYPE;
    # So let's say Your PageObject Class is 'DEMO_PAGE_CLASS_NAME', and it has several attributes
    # then see the below entry:
    # -----------------------------------------------------------------------------------------------------------
    "DEMO_PAGE_CLASS_NAME": {
        "PAGE_CLASS_ELEMENT_1": "<LOCATOR_TYPE>=<LOCATOR_VALUE>",
        "PAGE_SUBMIT_BTN_1": "xpath=//*[@role='button' and @type='submit']",
        "PAGE_SUBMIT_BTN_2": "id=submit_btn",
        "PAGE_SUBMIT_BTN_3": "name=submit_btn",
        "PAGE_SUBMIT_BTN_4": "css=.btn > submit",
        "PAGE_SUBMIT_BTN_5": "class=submit_btn_class",
        "PAGE_SUBMIT_BTN_6": "link=submit_btn_link",
    },

    # -----------------------------------------------------------------------------------------------------------
    # Start adding yours below this line [You may refer above demo/sample]
    # -----------------------------------------------------------------------------------------------------------
    "GoogleSearchPage": {
        "SEARCH_BOX": "xpath=//input[@name='q']",
        "SEARCH_SUBMIT_BTN": "xpath=//*[@name='btnK' and @type='submit']",
        "SEARCH_RESULT_FIRST_LINK": "xpath=(//*[@id='rso']//a)[1]",
    }
}
