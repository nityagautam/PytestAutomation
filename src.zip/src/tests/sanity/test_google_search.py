import pytest
import sys
import allure
from src.utilities.basetest import BaseTest
from src.pages.google_search.google_search_page import GoogleSearchPage
from src.config.config import Config


@pytest.mark.sanity
@pytest.mark.first
class TestGoogleSearch(BaseTest):

    # ------------------------------------------------
    # Before each Test def,
    # we need to initialize some page objects
    # ------------------------------------------------
    # @pytest.fixture(autouse=True)
    # def class_setup(self):
    #     self.loginPage = LoginPage(self.driver)
    #     self.config = Config()
    # -[END]-----------------------------------------------
    google_page = None

    # -[TESTs STARTS FROM HERE]-----------------------------------------------

    def test_search_google_and_browse_first_result(self):
        # Create object for page(s)
        self.google_page = GoogleSearchPage(self.driver)

        # Steps
        self.google_page.search('EARTH')
        self.google_page.extract_and_verify_for_results()
        self.google_page.browse_first_result_link()
        assert self.google_page.get_title() != "", "First link page is blank, which should not"

    def test_sample(self):
        assert True, "All good"
