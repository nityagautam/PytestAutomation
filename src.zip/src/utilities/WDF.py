"""
@package base

WebDriver Factory class implementation
It creates a web-driver instance based on browser configurations

"""
from selenium import webdriver
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.chrome import ChromeDriverManager
from src.config.config import Config


class WebDriverFactory:

    def __init__(self):
        """
        Inits WebDriverFactory class
        :Returns None:
        """
        # Extract the info from config
        self.browser = Config().BROWSER       # td.testData("browser")
        self.baseUrl = Config().ENV_URL   # td.testData("environment")

    def get_web_driver_instance(self):
        """
        Get WebDriver Instance based on the browser configuration
        :return 'WebDriver Instance':
        """

        if self.browser == "firefox":
            # Download Firefox driver on given PATH
            driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager(path=Config.WEB_DRIVER_PATH).install()))

        elif self.browser == "chrome":
            # Download Chrome driver on given PATH
            driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager(path=Config.WEB_DRIVER_PATH).install()))

        elif self.browser == "edge":
            # Download MS Edge driver on given PATH
            driver = webdriver.Edge(service=EdgeService(EdgeChromiumDriverManager(path=Config.WEB_DRIVER_PATH).install()))

        else:
            # Download Firefox driver on given PATH
            driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager(path=Config.WEB_DRIVER_PATH).install()))

        # Setting Driver Implicit Time out for An Element
        driver.implicitly_wait(Config.IMPLICIT_WAIT_TIMEOUT)
        # Maximize the window
        driver.maximize_window()
        # Loading browser with App URL
        driver.get(self.baseUrl)

        return driver


